<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	
	<meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Business: Business Multipurpose HTML template">
    <meta name="keywords" content="bootweb, multipurpose, portfolio, personal, developer, designer, onepage, clean, minimal, modern">
    <meta name="author" content="Tanmoy Dhar">
	
	  <!-- All CSS Files -->
    <link rel="shortcut icon" href="#" type="image/png">
    
    
  
   <?php wp_head(); ?>

</head>
<body>
     <!-- ==== Preloader start ==== -->
   <div id="loader-wrapper">
         <div id="loader"></div>
         <div class="loader-section section-left"></div>
         <div class="loader-section section-right"></div>
   </div>
   <!-- ==== Preloader end ==== -->
        <!-- Header start -->
    <header>
      <div class="hidden-xs hidden-sm nav-top primary-bg">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <div class="nav-top-access">
                <!-- Social links -->
                <ul>
                  <li><i class="fa fa-phone"></i> +1-1459-236-756</li>
                  <li><i class="fa fa-envelope" aria-hidden="true"></i>  contact@yourdomain.com</li>
                </ul>
              </div>
            </div>
            <div class="col-sm-6 text-right">
              <div class="nav-top-social">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
            <div class="menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="logo">
                                <!--== change the logo name ==-->
                                <a href="index.html">
                                   <h3><span>LO</span>GO</h3>
                                </a>
                            </div>
                            <!-- Responsive Menu Start -->
                            <div class="responsive-menu"></div>
                            <!-- Responsive Menu End -->
                        </div>
                        <div class="col-md-9 col-sm-12">
                            <div class="mainmenu">
                               <?php
          wp_nav_menu(array(
            'theme_location' => 'header_menu',
            'container' => ''
          ));
        ?>
                               <!--  <nav>
                                    <ul id="navigation">
                                        <li class="current-page-item"><a href="index.html">home</a>
                                             <ul>
                                                <li><a href="index.html">Home 1</a></li>
                                                <li><a href="index-2.html">Home 2</a></li>
                                                <li><a href="index-3.html">Home 3</a></li>
                                         
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="about.html">
                                            about us
                                            </a>
                                        </li>
                                        <li>
                                            <a href="service.html">services</a>
                                        </li>
                                        <li>
                                            <a href="portfolio.html">projects</a>
                                        </li>
                                        <li>
                                            <a href="blog-grid.html">blog</a>
                                            <ul>
                                                <li><a href="blog-grid.html">Blog Grid View</a></li>
                                                <li><a href="blog-left-sidebar.html">blog Left sidebar</a></li>
                                                 <li><a href="blog-right-sidebar.html">blog right sidebar</a></li>
                                                <li><a href="blog-details.html">blog Details</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="404-page.html">pages</a>
                                            <ul>
                                                <li><a href="404-page.html">404 page</a></li>
                                                <li><a href="faq.html">FAQs</a></li>
                                                <li><a href="pricing-table.html">pricing table</a></li>
                                                <li><a href="gallery.html">Gallery</a></li>
                                                <li><a href="team.html">team Page</a></li>
                                                <li><a href="single-team-page.html">Single team Page</a></li>    
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">contact</a></li>
                                    </ul>
                                </nav> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </header>
    <!-- Header End -->
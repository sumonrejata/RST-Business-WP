<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	
	<meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Business: Business Multipurpose HTML template">
    <meta name="keywords" content="bootweb, multipurpose, portfolio, personal, developer, designer, onepage, clean, minimal, modern">
    <meta name="author" content="Tanmoy Dhar">
	
	  <!-- All CSS Files -->
    <link rel="shortcut icon" href="#" type="image/png">
    
    
  
   <?php wp_head(); ?>

</head>
<body>
     <!-- ==== Preloader start ==== -->
   <div id="loader-wrapper">
         <div id="loader"></div>
         <div class="loader-section section-left"></div>
         <div class="loader-section section-right"></div>
   </div>
   <!-- ==== Preloader end ==== -->
        <!-- Header start -->
    <header>
      <div class="hidden-xs hidden-sm nav-top primary-bg">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <div class="nav-top-access">
                <!-- Social links -->
                <ul>
                  <li><i class="fa fa-phone"></i> +1-1459-236-756</li>
                  <li><i class="fa fa-envelope" aria-hidden="true"></i>  contact@yourdomain.com</li>
                </ul>
              </div>
            </div>
            <div class="col-sm-6 text-right">
              <div class="nav-top-social">
                <ul>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
            <div class="menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="logo">
                                <!--== change the logo name ==-->
                                <a href="index.html">
                                   <h3><span>LO</span>GO</h3>
                                </a>
                            </div>
                            <!-- Responsive Menu Start -->
                            <div class="responsive-menu"></div>
                            <!-- Responsive Menu End -->
                        </div>
                        <div class="col-md-9 col-sm-12">
                            <div class="mainmenu">
                               <?php
          wp_nav_menu(array(
            'theme_location' => 'header_menu',
            'container' => ''
          ));
        ?>
                               <!--  <nav>
                                    <ul id="navigation">
                                        <li class="current-page-item"><a href="index.html">home</a>
                                             <ul>
                                                <li><a href="index.html">Home 1</a></li>
                                                <li><a href="index-2.html">Home 2</a></li>
                                                <li><a href="index-3.html">Home 3</a></li>
                                         
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="about.html">
                                            about us
                                            </a>
                                        </li>
                                        <li>
                                            <a href="service.html">services</a>
                                        </li>
                                        <li>
                                            <a href="portfolio.html">projects</a>
                                        </li>
                                        <li>
                                            <a href="blog-grid.html">blog</a>
                                            <ul>
                                                <li><a href="blog-grid.html">Blog Grid View</a></li>
                                                <li><a href="blog-left-sidebar.html">blog Left sidebar</a></li>
                                                 <li><a href="blog-right-sidebar.html">blog right sidebar</a></li>
                                                <li><a href="blog-details.html">blog Details</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="404-page.html">pages</a>
                                            <ul>
                                                <li><a href="404-page.html">404 page</a></li>
                                                <li><a href="faq.html">FAQs</a></li>
                                                <li><a href="pricing-table.html">pricing table</a></li>
                                                <li><a href="gallery.html">Gallery</a></li>
                                                <li><a href="team.html">team Page</a></li>
                                                <li><a href="single-team-page.html">Single team Page</a></li>    
                                            </ul>
                                        </li>
                                        <li><a href="contact.html">contact</a></li>
                                    </ul>
                                </nav> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </header>
    <!-- Header End -->

     <!-- == Home Section Start == -->
    <section id="home" >
        <!-- == Color schemes == -->
    	  <div class="color-schemes">
    	  	 <div class="color-handle">
                 <i class="fa fa-cogs fa-spin" aria-hidden="true"></i>
    	  	 </div>
    	  	 <div class="color-plate">
      		     <h5>Chose color</h5>
    		       <a href="css/colors/defaults-color.css" class="single-color defaults-color">Defaults</a>
               <a href="css/colors/red-color.css" class="single-color red-color">Red</a>
               <a href="css/colors/purple-color.css" class="single-color purple-color">Purple</a>
               <a href="css/colors/sky-color.css" class="single-color sky-color">sky</a>
               <a href="css/colors/green-color.css" class="single-color green-color">Green</a>
               <a href="css/colors/blue-color.css" class="single-color pink-color">Pink</a>
    	  	  </div>
    	  </div>
        <!-- == /Color schemes == -->	
        <!-- silider start -->
        <div class="main-slider-1 white-clr-all">
          <div id="carosel-mr-1" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carosel-mr-1" data-slide-to="0" class="active"></li>
              <li data-target="#carosel-mr-1" data-slide-to="1"></li>
              <li data-target="#carosel-mr-1" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner main-sld" role="listbox">
              <div class="item active main-sld">
                <!-- change slider image -->
                <div class="slider-bg" style="background-image: url('<?php echo get_template_directory_uri(); ?>/image/slider/dummy-slider.jpg');"></div>
                <div class="slider-cell">
                  <div class="slider-ver">
                    <div class="slider-con text-center">
                      <h1>Grow Your <span>Business</span></h1>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum expedita maxime culpa.</p>
                      <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="#">View Demo</a>
                      <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="#">Find More</a>
                    </div>
                    <!-- end slider content -->
                  </div>
                </div>
              </div>
              <!-- end single item -->
              <div class="item main-sld">
                <!-- change slider image -->
                <div class="slider-bg" style="background-image: url('<?php echo get_template_directory_uri(); ?>/image/slider/dummy-slider.jpg');"></div>
                <div class="slider-cell">
                  <div class="slider-ver">
                    <div class="slider-con text-center">
                      <h1>Grow Your <span>Businesss</span></h1>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum expedita maxime culpa.</p>
                      <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="#">View Demo</a>
                      <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="#">Find More</a>
                    </div>
                    <!-- end slider content -->
                  </div>
                </div>
              </div>
              <!-- end single item -->
              <div class="item main-sld">
                <!-- change slider image -->
                <div class="slider-bg" style="background-image: url('<?php echo get_template_directory_uri(); ?>/image/slider/dummy-slider.jpg');"></div>
                <div class="slider-cell">
                  <div class="slider-ver">
                    <div class="slider-con text-center">
                      <h1>Increase Product <span>Sales </span></h1>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum expedita maxime culpa.</p>
                      <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="#">View Demo</a>
                      <a class="btn btn-default btn-animate btn-style hvr-shutter-out-vertical" href="#">Find More</a>
                    </div>
                    <!-- end slider content -->
                  </div>
                </div>
              </div>
              <!-- end single item -->
            </div>
            <a class="left slide-control-mr" href="#carosel-mr-1" role="button" data-slide="prev"><i class="fa fa-angle-left"></i></a>
            <a class="right slide-control-mr" href="#carosel-mr-1" role="button" data-slide="next"><i class="fa fa-angle-right"></i></a>
          </div>
        </div>
        <!-- end slider bar -->
        <!--slider section start-->	
    </section>
    <!-- == Home Section End == -->

    <!-- == About Section Start == -->
    <section id="about" class="about section-padding-top">
    	<div class="container">
    		<div class="section-title">
    			<h2>About <span>Us</span></h2>
    			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
    		</div>
    		<div class="row">
    			<!-- About image -->
    			<div class="col-md-6">
    				<a href="#" class="img-about">
    					<img src="<?php echo get_template_directory_uri(); ?>/image/about/dummy-image.jpg" alt="" class="img-responsive">
    				</a>
    			</div>
    			<div class="col-md-6">
            <!-- About text-->
    				<div class="about-details">
    					<h5>WHAT WE ARE</h5>
    					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed commodo tellus pulvinar. Donec sodales tortor vitae leo bibendum tincidunt. Suspendisse posuere quam eget porta tempor. Cras tempor bibendum libero, non semper velit bibendum. Integer posuere augue eu feugiat congue.</p>
    				    <ul class="image-contact-list">
    				    	<li><i class="icofont icofont-speech-comments"></i> <span> Reliable and Secure Platform</span></li>
    				    	<li><i class="icofont icofont-package"></i> <span>Everything is perfectly organized</span></li>
    				    	<li><i class="icofont icofont-settings"></i> <span>Simple Line Icon</span></li>
    				    	<li><i class="icofont icofont-gift"></i> <span>Step on the new level</span></li>

    				    </ul>
    				    <a class="btn btn-default btn-style hvr-shutter-out-vertical" href="#">Read More</a>
    				</div>
            <!-- /About text -->
    			</div>
    		</div>
    	</div>
    </section>
    <!-- == About Section End == -->

    <!-- == Service Section Start == -->
    <section id="service" class="service section-padding-top">
    	<div class="container">
    		<div class="section-title">
    			<h2>Our <span>Services</span></h2>
    			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
    		</div>
    		<div class="row content service-grid-s1">
    			<!-- single serivce-->
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                 <i class="fa fa-graduation-cap"></i>
              </div>
              <div class="details">
                  <h3><a href="#">Financial Planning</a></h3>
                  <p> Business Loan Our cross stage cunt be applications intended for iPhone, Blackberry, Android and so on run consist</p>
              </div>
    				</div>
    			</div>
    			<!-- single serivce-->
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                <i class="fa fa-credit-card"></i>
              </div>
              <div class="details">
                  <h3><a href="#">Business Loan </a></h3>
                  <p> Business Loan Our cross stage cunt be applications intended for iPhone, Blackberry, Android and so on run consist</p>
              </div>
    				</div>
    			</div>
    			<!-- single serivce-->
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                <i class="fa fa-subway"></i>
              </div>
              <div class="details">
                  <h3><a href="#">Retairement Planning</a></h3>
                  <p> Business Loan Our cross stage cunt be applications intended for iPhone, Blackberry, Android and so on run consist</p>
              </div>
    				</div>
    			</div>
    			<!-- single serivce-->
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                <i class="fa fa-archive"></i>
              </div>
              <div class="details">
                  <h3><a href="#">Insurance Consulting </a></h3>
                  <p> Business Loan Our cross stage cunt be applications intended for iPhone, Blackberry, Android and so on run consist</p>
              </div>
    				</div>
    			</div>
    			<!-- single serivce-->
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                 <i class="fa fa-rocket"></i>
              </div>
              <div class="details">
                  <h3><a href="#">Taxes Planning</a></h3>
                  <p> Business Loan Our cross stage cunt be applications intended for iPhone, Blackberry, Android and so on run consist</p>
              </div>
    				</div>
    			</div>
    			<!-- single serivce-->
    			<div class="col-md-4 col-sm-6">
    				<div class="grid">
    					<div class="icon">
                <i class="fa fa-universal-access"></i>
              </div>
              <div class="details">
                  <h3><a href="#">Mutual funds</a></h3>
                  <p> Business Loan Our cross stage cunt be applications intended for iPhone, Blackberry, Android and so on run consist</p>
              </div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>
    <!-- == Service Section End == -->

    <!-- == Team Section Start == -->
    <section id="team" class="section-padding">
      <div class="container">
        <div class="section-title">
          <h2>Our Best <span>Team</span></h2>
          <span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
        </div>
        <div class="row">
            <!-- Single team item-->  
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="team-single text-center m-b-30">
                    <div class="team-img">
                        <img src="<?php echo get_template_directory_uri(); ?>/image/team/dummy-image.jpg" alt="" class="img img-responsive">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                     <div class="team-content">
                        <h3><a href="single-team-page.html">John Doe</a></h3>
                        <span>Founder</span>
                    </div>
                </div>
            </div>
            <!-- Single team item-->  
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="team-single text-center m-b-30">                       
                    <div class="team-img">
                        <img src="<?php echo get_template_directory_uri(); ?>/image/team/dummy-image.jpg" alt="" class="img img-responsive">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <h3><a href="single-team-page.html">John Doe</a></h3>
                        <span>CEO</span>
                    </div>
                </div>
            </div>
            <!-- Single team item-->  
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="team-single text-center m-b-30">                     
                    <div class="team-img">
                        <img src="<?php echo get_template_directory_uri(); ?>/image/team/dummy-image.jpg" alt="" class="img img-responsive">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <h3><a href="single-team-page.html">John Doe</a></h3>
                        <span>Managing Director</span>
                    </div>
                </div>
            </div>
            <!-- Single team item-->  
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="team-single text-center m-b-30">                   
                    <div class="team-img">
                        <img src="<?php echo get_template_directory_uri(); ?>/image/team/dummy-image.jpg" alt="" class="img img-responsive">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                    <div class="team-content">
                        <h3><a href="single-team-page.html">John Doe</a></h3>
                        <span>Administrative Officer</span>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </section>
    <!-- == Team Section End == -->

    <!-- == Counter Section Start == -->
    <section id="counter" class="counter-bg bg-opacity section-padding-60">
    	<div class="container">
    		<div class="row">
    		<!-- Counter item-->	
    	    <div class="col-md-3 col-sm-6">
    	    	<div class="counter-item style-2">
    	    		<div class="counter-item-inner">
    	    		<i class="fa fa-desktop" aria-hidden="true"></i>
    					<h4>Projects Done</h4>
    					<span class="counter">1000</span>
    	    		</div>
    	    	</div>
    	    </div>
    	    <!-- Counter item-->	
    	    <div class="col-md-3 col-sm-6">
    	    	<div class="counter-item style-2">
    	    		<div class="counter-item-inner">
                <div class="icon"></div>
    	    			<i class="fa fa-smile-o"></i>
    					  <h4>Happy Clients</h4>
    					  <span class="counter">2000</span>
    	    		</div>
    	    	</div>
    	    </div>
    	    <!-- Counter item-->	
    	    <div class="col-md-3 col-sm-6">
    	    	<div class="counter-item style-2">          
    	    		<div class="counter-item-inner">
                <div class="icon"></div>
    	    			<i class="fa fa-users" aria-hidden="true"></i>
    					  <h4>Employees</h4>
    					  <span class="counter">215</span>
    	    		</div>
    	    	</div>
    	    </div>
    	    <!-- Counter item-->	
    	    <div class="col-md-3 col-sm-6">
    	    	<div class="counter-item style-2">
    	    		<div class="counter-item-inner">
                <div class="icon"></div>
      	    		<i class="fa fa-trophy" aria-hidden="true"></i>
      					<h4>Awards</h4>
      					<span class="counter">3000</span>
    	    		</div>
    	    	</div>
    	    </div>
    		</div>
    	</div>
    </section>
    <!-- == Counter Section End == -->

    <!-- == Pricing Table Section Start == -->
    <section id="portfolio-section" class="portfolio section-padding-top">
      <div class="container">
        <div class="section-title">
          <h2>Pricing<span>Table</span></h2>
          <span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
        </div>
        <div class="row">
           <div class="col-md-3">
                <div class="pricing-item text-center">
                  <div class="pricing-heading">
                    <h6 class="title">Basic</h6>
                  </div>
                  <div class="pricing-body">
                    <div class="rate">
                      <h3 class="amount">$15</h3>
                      <h6 class="validity">Month</h6>
                    </div>
                      <ul class="pricing-list">
                        <li>Full Access</li>
                        <li>Unlimited Bandwidth</li>
                        <li>30 GB Space</li>
                        <li>1 Month Support</li>
                        <li>20 E-mail Accounts</li>
                        <li>24/7 Support</li>
                      </ul>
                     <a class="button btn btn-default btn-style hvr-shutter-out-vertical " href="#">Order Now</a>

                  </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="pricing-item text-center">
                  <div class="pricing-heading">
                    <h6 class="title">Professional</h6>
                  </div>
                  <div class="pricing-body">
                    <div class="rate">
                      <h3 class="amount">$25</h3>
                      <h6 class="validity">Month</h6>
                    </div>
                      <ul class="pricing-list">
                        <li>Full Access</li>
                        <li>Unlimited Bandwidth</li>
                        <li>50 GB Space</li>
                        <li>1 Month Support</li>
                        <li>20 E-mail Accounts</li>
                        <li>24/7 Support</li>
                      </ul>
                     <a class="button btn btn-default btn-style hvr-shutter-out-vertical " href="#">Order Now</a>

                  </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="pricing-item text-center active-pricing">
                  <div class="pricing-heading">
                    <h6 class="title">Business</h6>
                  </div>
                  <div class="pricing-body">
                    <div class="rate">
                      <h3 class="amount">$55</h3>
                      <h6 class="validity">Month</h6>
                    </div>
                      <ul class="pricing-list">
                        <li>Full Access</li>
                        <li>Unlimited Bandwidth</li>
                        <li>100 GB Space</li>
                        <li>1 Month Support</li>
                        <li>100 E-mail Accounts</li>
                        <li>24/7 Support</li>
                      </ul>
                      <a class="button btn btn-default btn-style hvr-shutter-out-vertical " href="#">Order Now</a>
                  </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="pricing-item text-center">
                  <div class="pricing-heading">
                    <h6 class="title">CORPORATE</h6>
                  </div>
                  <div class="pricing-body">
                    <div class="rate">
                      <h3 class="amount">$100</h3>
                      <h6 class="validity">Month</h6>
                    </div>
                      <ul class="pricing-list">
                        <li>Full Access</li>
                        <li>Unlimited Bandwidth</li>
                        <li>100 GB Space</li>
                        <li>1 Month Support</li>
                        <li>100 E-mail Accounts</li>
                        <li>24/7 Support</li>
                      </ul>
                     <a class="button btn btn-default btn-style hvr-shutter-out-vertical " href="#">Order Now</a>
                  </div>
                </div>
            </div>
        </div>
      </div>
    </section>
    <!-- == Pricing Table Section End == -->


   <!-- ==== Portfolio section start ==== -->
    <section class="section-padding gray-brackground" id="portfolio">
       <div class="container">
       		<div class="section-title">
      			<h2>Our <span>Project</span></h2>
      			<span class="s-title-icon"><i class="icofont icofont-diamond"></i></span>
    		  </div>
          <div class="portfolio-content">
             <!-- Protfolio navbar -->
             <div class="portfolio-filter-wrap text-center" >
                 <ul class="portfolio-filter hover-style-one">
                     <li class="active"><a href="#" data-filter="*"> All</a></li>
                     <li><a href="#" data-filter=".cat1">WEB Design</a></li>
                     <li><a href="#" data-filter=".cat2">Mobile</a></li>
                     <li><a href="#" data-filter=".cat3">SEO</a></li>
                     <li><a href="#" data-filter=".cat4">Photography</a></li>
                     <li><a href="#" data-filter=".cat5">Development</a></li>
                 </ul>
             </div>
             <div class="portfolio portfolio-gutter portfolio-style-2 portfolio-container portfolio-masonry portfolio-column-count-4 ">
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat1 cat3">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                             <!-- Change the dummy image -->
                             <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                  
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat1 cat2">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                            <!-- Change the dummy image -->
                            <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                          
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat3 cat4 cat2 cat1">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                            <!-- Change the dummy image -->
                            <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                      
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat1 cat3 cat5">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                             <!-- Change the dummy image -->
                             <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                       
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat5 cat2 cat4">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                             <!-- Change the dummy image -->
                             <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                    
                            <!-- Change the dummy image -->
                            <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat1 cat5 cat3">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                             <!-- Change the dummy image -->
                             <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                     
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                   <!-- Single portfolio item -->
                 <div class="portfolio-item cat1 cat3">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                             <!-- Change the dummy image -->
                             <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                     
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat1 cat2">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                            <!-- Change the dummy image -->
                            <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                   
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
                 <!-- Single portfolio item -->
                 <div class="portfolio-item cat3 cat4 cat2 cat1">
                     <div class="portfolio-item-content">
                         <div class="item-thumbnail">
                            <!-- Change the dummy image -->
                            <img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="">
                         </div>
                         <div class="portfolio-description">
                             <h4><a href="#" >project title</a></h4>
                       
                             <!-- Change the dummy image -->
                             <a href="image/portfolio/dummy-image.jpg" class="portfolio-gallery-set"><i class="fa fa-search-plus"></i></a><a target="_blank" href="#"><i class="fa fa-link"></i></a>
                         </div>                                    
                     </div>
                 </div>
             </div>          
             <div class="text-center">
                <a class="btn btn-default btn-style hvr-shutter-out-vertical" href="#">View More</a>
             </div>           
          </div>	 
       </div>
    </section>
    <!-- ==== Protfolio section end ==== -->
 <!-- ==== footer section start ==== -->
    <footer class="footer-bg section-padding-top footer">
      <div class="footer-widget-area">
        <div class="container">
          <div class="row">
            <div class="col-md-3">
              <div class="f-widget">
                <a href="index.html">
                  <!-- Change the logo here-->
                  <h4 class="logo-text1"><span>LO</span>GO</h4>
                </a>
                <p class="m-t-30">Lorem ipsum dolor sit amet, adipiscing elit. Donec elit erat, vestibulum ac luctus id, ultrices.</p>
                <ul class="f-address">
                  <li><i class="fa fa-map-marker" aria-hidden="true"></i> 25/1 London road, Brighum,London</li>
                  <li><i class="fa fa-phone"></i> +1-1459-236-756</li>
                  <li><i class="fa fa-envelope" aria-hidden="true"></i>  contact@yourdomain.com</li>
                </ul>
              </div>
            </div>
            <div class="col-md-3">
              <div class="f-widget">
                <div class="f-widget-title">
                   <h4>Useful links</h4>
                </div>
                  <ul class="useful-links">
                  <li><i class="fa fa-caret-right" aria-hidden="true"></i> <a href="#">General Information For Users</a></li>
                  <li><i class="fa fa-caret-right" aria-hidden="true"></i> <a href="#">Interactive Fairy Tales</a></li>
                  <li><i class="fa fa-caret-right" aria-hidden="true"></i> <a href="#">Official Storybook Maker</a></li>
                  <li><i class="fa fa-caret-right" aria-hidden="true"></i> <a href="#">Everyday Mathematics Links</a></li>
                  <li><i class="fa fa-caret-right" aria-hidden="true"></i> <a href="#">Basic Knowledge</a></li>
                </ul>
              </div>
            </div>
            <div class="col-md-3">
                  <div class="f-widget">
                  <div class="f-widget-title">
                    <h4>Instagram Feeds</h4>
                  </div>
                  <ul class="instagram-widget">
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                     <li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/image/portfolio/dummy-image.jpg" alt="" class="img-responsive"></a></li>
                  </ul>
              </div>
            </div>
            <div class="col-md-3">
                <div class="f-widget">
                <div class="f-widget-title">
                  <h4>Newsletter</h4>
                </div>
                <p>Subscribe to our MailChimp newsletter and stay up to date with all events coming straight in your mailbox:</p>
                <div class="newsletter">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Your email Address" aria-label="Search for..." autocomplete="off">
                    <span class="input-group-btn">
                      <button class="btn newsletter-btn" type="button"><i class="fa Example of paper-plane fa-paper-plane"></i></button>
                    </span>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="copyright-area">
        <div class="container">
          <div class="row text-center">
             <div class="copyright-social">
                  <ul class="social-profile">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                  </ul>
             </div> 
             <div class="copyright-text">
                <p>© Copyright 2018. All Rights Reserved. Designed by <a href="#">Synchrotheme</a></p>
             </div>
          </div>
        </div>
      </div>
    </footer>
    <!-- ==== footer section end ==== -->

    <!-- All JS Here -->
   
  



<?php wp_footer(); ?>

</body>
</html>